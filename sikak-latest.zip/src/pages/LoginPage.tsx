import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import sikakLogo from "@/assets/sikak-logo.png";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!username || !password) {
      setError("Silakan isi username/email dan password");
      return;
    }

    try {
      setIsLoading(true);
      await login(username, password);
      navigate("/app", { replace: true });
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message === "Akun tidak aktif. Hubungi administrator.") {
        setError(message);
      } else if (
        message.includes("Username tidak ditemukan") ||
        message.includes("salah")
      ) {
        setError("Username/email atau password salah");
      } else {
        setError("Gagal masuk. Silakan coba lagi.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <div className="flex-1 bg-white flex items-center justify-center px-8 py-12">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-8 h-36 w-36 rounded-full bg-sky-100 flex items-center justify-center">
            <img src={sikakLogo} alt="SIKAK Logo" width={88} height={88} />
          </div>
          <h1 className="text-4xl font-bold text-sky-700 mb-2">SIKAK 1.0</h1>
          <p className="text-lg text-slate-700 leading-relaxed">
            Sistem Informasi Kartu Asuhan Keperawatan Keluarga
          </p>
          <p className="text-sm text-slate-400 mt-4">
            Platform digital layanan keperawatan keluarga
          </p>
        </div>
      </div>

      <div className="flex-1 bg-sky-600 flex items-center justify-center px-8 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 text-center">
            <h2 className="text-3xl font-bold text-white">Masuk ke Sistem</h2>
            <p className="text-sm text-white/80 mt-2">
              Gunakan username atau email petugas Anda
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-white/15 border border-white/30 text-white text-sm">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-white mb-1.5">
                Username atau Email
              </label>
              <Input
                type="text"
                placeholder="Masukkan username atau email"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                className="bg-white/95 border-white/80 text-slate-900 placeholder:text-slate-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-1.5">
                Password
              </label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Masukkan password Anda"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  className="pr-10 bg-white/95 border-white/80 text-slate-900 placeholder:text-slate-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-700"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-white text-sky-700 hover:bg-sky-50"
              disabled={isLoading}
            >
              {isLoading && (
                <span className="animate-spin h-4 w-4 border-2 border-sky-700 border-t-transparent rounded-full mr-2" />
              )}
              {isLoading ? "Memproses..." : "Masuk"}
            </Button>
          </form>

          <p className="text-xs text-center text-white/70 mt-10">
            © 2026 - Pemerintahan Kabupaten Ponorogo
          </p>
        </div>
      </div>
    </div>
  );
}
