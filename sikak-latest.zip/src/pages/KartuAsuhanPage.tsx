import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

type KartuItem = {
  id: string;
  idKeluarga: string;
  idAnggota: string;
  namaKepala: string;
  namaAnggota: string;
  namaPoli: string;
  tanggal: string;
  status: string;
  preview: string;
};

type KeluargaOption = {
  id: string;
  nama: string;
};

type AnggotaOption = {
  id: string;
  idKeluarga: string;
  nama: string;
};

type KakDetail = {
  dataPengkajian: string;
  diagnosisKeperawatan: string;
  rencanaIntervensi: string;
  implementasi: string;
  petugasKesehatan: string;
};

export default function KartuAsuhanPage() {
  const navigate = useNavigate();
  const { user, role } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [kartuList, setKartuList] = useState<KartuItem[]>([]);
  const [keluargaOptions, setKeluargaOptions] = useState<KeluargaOption[]>([]);
  const [anggotaOptions, setAnggotaOptions] = useState<AnggotaOption[]>([]);
  const [selectedKeluargaId, setSelectedKeluargaId] = useState("");
  const [selectedAnggotaId, setSelectedAnggotaId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedKartu, setSelectedKartu] = useState<KartuItem | null>(null);
  const [isDetailLoading, setIsDetailLoading] = useState(false);
  const [detailData, setDetailData] = useState<KakDetail | null>(null);

  const canInput = role === "user_poli";

  useEffect(() => {
    const fetchData = async () => {
      const idPuskesmas = user?.id_puskesmas;
      if (!idPuskesmas) {
        setKartuList([]);
        setKeluargaOptions([]);
        setAnggotaOptions([]);
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const [kartuRes, keluargaRes, anggotaRes] = await Promise.all([
          (supabase as any)
            .from("kartu_asuhan_keperawatan")
            .select("*, kak_rows(*)")
            .eq("id_puskesmas", idPuskesmas)
            .order("created_at", { ascending: false }),
          (supabase as any)
            .from("keluarga")
            .select("id, nama_kepala_keluarga")
            .eq("id_puskesmas", idPuskesmas)
            .order("nama_kepala_keluarga", { ascending: true }),
          (supabase as any)
            .from("anggota_keluarga")
            .select("id, id_keluarga, nama")
            .order("urutan", { ascending: true }),
        ]);

        const keluargaMap = new Map<string, string>(
          ((keluargaRes.data ?? []) as Array<Record<string, unknown>>).map((row, idx) => [
            String(row.id ?? idx),
            String(row.nama_kepala_keluarga ?? "-"),
          ]),
        );
        const anggotaMap = new Map<string, string>(
          ((anggotaRes.data ?? []) as Array<Record<string, unknown>>).map((row, idx) => [
            String(row.id ?? idx),
            String(row.nama ?? "-"),
          ]),
        );

        const mappedKartu: KartuItem[] = ((kartuRes.data ?? []) as Array<Record<string, unknown>>).map((row, idx) => {
          const rows = Array.isArray(row.kak_rows) ? (row.kak_rows as Array<Record<string, unknown>>) : [];
          const previewRaw = String(rows[0]?.catatan ?? rows[0]?.konten ?? rows[0]?.diagnosis ?? "Konten asuhan tersedia");
          return {
            id: String(row.id ?? idx),
            idKeluarga: String(row.id_keluarga ?? ""),
            idAnggota: String(row.id_anggota_keluarga ?? ""),
            namaKepala: keluargaMap.get(String(row.id_keluarga ?? "")) ?? String(row.nama_kepala_keluarga ?? "-"),
            namaAnggota: anggotaMap.get(String(row.id_anggota_keluarga ?? "")) ?? String(row.nama_anggota ?? "-"),
            namaPoli: String(row.nama_poli ?? row.poli ?? "Poli"),
            tanggal: String(row.tanggal ?? row.created_at ?? ""),
            status: String(row.status ?? "pending"),
            preview: previewRaw,
          };
        });

        const mappedKeluarga: KeluargaOption[] = ((keluargaRes.data ?? []) as Array<Record<string, unknown>>).map((row, idx) => ({
          id: String(row.id ?? idx),
          nama: String(row.nama_kepala_keluarga ?? "-"),
        }));
        const mappedAnggota: AnggotaOption[] = ((anggotaRes.data ?? []) as Array<Record<string, unknown>>).map((row, idx) => ({
          id: String(row.id ?? idx),
          idKeluarga: String(row.id_keluarga ?? ""),
          nama: String(row.nama ?? "-"),
        }));

        setKartuList(mappedKartu);
        setKeluargaOptions(mappedKeluarga);
        setAnggotaOptions(mappedAnggota);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [user?.id_puskesmas]);

  const anggotaCascade = useMemo(() => {
    if (!selectedKeluargaId) return [];
    return anggotaOptions.filter((item) => item.idKeluarga === selectedKeluargaId);
  }, [anggotaOptions, selectedKeluargaId]);

  const filteredCards = useMemo(() => {
    return kartuList.filter((item) => {
      const matchKeluarga = !selectedKeluargaId || item.idKeluarga === selectedKeluargaId;
      const matchAnggota = !selectedAnggotaId || item.idAnggota === selectedAnggotaId;
      const matchStart = !startDate || (item.tanggal && item.tanggal >= startDate);
      const matchEnd = !endDate || (item.tanggal && item.tanggal <= endDate);
      return matchKeluarga && matchAnggota && matchStart && matchEnd;
    });
  }, [endDate, kartuList, selectedAnggotaId, selectedKeluargaId, startDate]);

  useEffect(() => {
    const fetchDetail = async () => {
      if (!selectedKartu) {
        setDetailData(null);
        return;
      }
      setIsDetailLoading(true);
      try {
        const { data } = await (supabase as any)
          .from("kak_rows")
          .select("*")
          .eq("id_kak", selectedKartu.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        setDetailData({
          dataPengkajian: String(data?.data_pengkajian ?? data?.pengkajian ?? "-"),
          diagnosisKeperawatan: String(
            data?.diagnosis_keperawatan ?? data?.diagnosis ?? "-",
          ),
          rencanaIntervensi: String(
            data?.rencana_intervensi ?? data?.intervensi ?? "-",
          ),
          implementasi: String(data?.implementasi ?? "-"),
          petugasKesehatan: String(
            data?.petugas_kesehatan ?? data?.petugas ?? "-",
          ),
        });
      } finally {
        setIsDetailLoading(false);
      }
    };

    fetchDetail();
  }, [selectedKartu]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-foreground">Kartu Asuhan Keperawatan</h1>
        {canInput && (
          <button
            type="button"
            onClick={() => navigate("/app/kartu/baru")}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            + Input Kartu Asuhan Baru
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <select
          value={selectedKeluargaId}
          onChange={(e) => {
            setSelectedKeluargaId(e.target.value);
            setSelectedAnggotaId("");
          }}
          className="rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="">Pilih Keluarga</option>
          {keluargaOptions.map((item) => (
            <option key={item.id} value={item.id}>
              {item.nama}
            </option>
          ))}
        </select>
        <select
          value={selectedAnggotaId}
          onChange={(e) => setSelectedAnggotaId(e.target.value)}
          className="rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="">Pilih Anggota</option>
          {anggotaCascade.map((item) => (
            <option key={item.id} value={item.id}>
              {item.nama}
            </option>
          ))}
        </select>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className="rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
      </div>

      {isLoading ? (
        <div className="flex items-center gap-3 py-10 text-muted-foreground">
          <span className="h-5 w-5 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          Memuat kartu asuhan...
        </div>
      ) : filteredCards.length === 0 ? (
        <div className="text-sm text-muted-foreground">Belum ada kartu asuhan</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCards.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelectedKartu(item)}
              className={`text-left rounded-lg border p-4 transition-colors ${
                item.status === "pending" ? "bg-yellow-50 border-yellow-200" : "bg-white border-slate-200"
              }`}
            >
              <p className="text-base font-semibold text-foreground">{item.namaKepala}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {item.namaPoli} | {item.tanggal ? new Date(item.tanggal).toLocaleDateString("id-ID") : "-"}
              </p>
              <p
                className="text-sm text-muted-foreground mt-3 select-none"
                style={{ filter: "blur(3px)", userSelect: "none" }}
              >
                {item.preview}
              </p>
              <p className="text-xs text-primary mt-3">Klik untuk lihat detail</p>
            </button>
          ))}
        </div>
      )}

      {selectedKartu && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-lg border border-border bg-card print:shadow-none">
            <div className="border-b border-border px-5 py-4">
              <h2 className="text-lg font-semibold text-foreground">Detail Kartu Asuhan</h2>
            </div>
            <div className="p-5 space-y-4 text-sm">
              <div className="rounded-md border border-border bg-muted/40 p-3">
                <p className="text-foreground font-medium">
                  {selectedKartu.namaKepala} - {selectedKartu.namaAnggota}
                </p>
                <p className="text-muted-foreground">
                  {selectedKartu.namaPoli} |{" "}
                  {selectedKartu.tanggal
                    ? new Date(selectedKartu.tanggal).toLocaleDateString("id-ID")
                    : "-"}
                </p>
              </div>

              {isDetailLoading ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span className="h-4 w-4 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                  Memuat detail KAK...
                </div>
              ) : (
                <>
                  <DetailRow
                    label="Data Pengkajian"
                    content={detailData?.dataPengkajian ?? "-"}
                  />
                  <DetailRow
                    label="Diagnosis Keperawatan"
                    content={detailData?.diagnosisKeperawatan ?? "-"}
                  />
                  <DetailRow
                    label="Rencana Intervensi"
                    content={detailData?.rencanaIntervensi ?? "-"}
                  />
                  <DetailRow
                    label="Implementasi"
                    content={detailData?.implementasi ?? "-"}
                  />
                  <DetailRow
                    label="Petugas Kesehatan"
                    content={detailData?.petugasKesehatan ?? "-"}
                  />
                </>
              )}
            </div>
            <div className="border-t border-border p-4 flex justify-end gap-2 print:hidden">
              <button
                type="button"
                onClick={() => window.print()}
                className="rounded-md border border-primary px-4 py-2 text-sm text-primary hover:bg-primary/5"
              >
                Cetak KAK ini
              </button>
              <button
                type="button"
                onClick={() => setSelectedKartu(null)}
                className="rounded-md border border-border px-4 py-2 text-sm text-foreground hover:bg-muted"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailRow({ label, content }: { label: string; content: string }) {
  return (
    <div className="rounded-md border border-border p-3">
      <p className="font-semibold text-foreground">{label}</p>
      <p className="text-foreground whitespace-pre-wrap mt-1">{content || "-"}</p>
    </div>
  );
}
