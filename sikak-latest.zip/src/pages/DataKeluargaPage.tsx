import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, Pencil, Trash2 } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type KeluargaItem = {
  id: string;
  kodeKK: string;
  namaKepala: string;
  alamat: string;
  telepon: string;
  jumlahAnggota: number;
};

type KeluargaForm = {
  kode: string;
  nama_kepala_keluarga: string;
  alamat_keluarga: string;
  telp_keluarga: string;
  jumlah_anggota: string;
};

type AnggotaItem = {
  id: string;
  nama: string;
  hubungan: string;
  urutan: number;
};

type AnggotaForm = {
  nama: string;
  hubungan: string;
  urutan: string;
};

export default function DataKeluargaPage() {
  const navigate = useNavigate();
  const { user, role } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [keluargaList, setKeluargaList] = useState<KeluargaItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof KeluargaForm, string>>>({});
  const [formData, setFormData] = useState<KeluargaForm>({
    kode: "",
    nama_kepala_keluarga: "",
    alamat_keluarga: "",
    telp_keluarga: "",
    jumlah_anggota: "",
  });
  const [detailKeluarga, setDetailKeluarga] = useState<KeluargaItem | null>(null);
  const [anggotaList, setAnggotaList] = useState<AnggotaItem[]>([]);
  const [isDetailLoading, setIsDetailLoading] = useState(false);
  const [isAnggotaModalOpen, setIsAnggotaModalOpen] = useState(false);
  const [isSavingAnggota, setIsSavingAnggota] = useState(false);
  const [anggotaError, setAnggotaError] = useState<Partial<Record<keyof AnggotaForm, string>>>({});
  const [anggotaForm, setAnggotaForm] = useState<AnggotaForm>({
    nama: "",
    hubungan: "",
    urutan: "",
  });
  const canManage = role === "user_du";

  const fetchKeluarga = async () => {
    const idPuskesmas = user?.id_puskesmas;
    if (!idPuskesmas) {
      setKeluargaList([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const { data } = await (supabase as any)
        .from("keluarga")
        .select("*")
        .eq("id_puskesmas", idPuskesmas)
        .order("created_at", { ascending: false });

      const mapped: KeluargaItem[] = ((data ?? []) as Array<Record<string, unknown>>).map((row, index) => ({
        id: String(row.id ?? index),
        kodeKK: String(row.kode ?? "-"),
        namaKepala: String(row.nama_kepala_keluarga ?? "-"),
        alamat: String(row.alamat_keluarga ?? "-"),
        telepon: String(row.telp_keluarga ?? "-"),
        jumlahAnggota: Number(row.jumlah_anggota ?? 0),
      }));
      setKeluargaList(mapped);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchKeluarga();
  }, [user?.id_puskesmas]);

  const filteredData = useMemo(() => {
    const keyword = search.trim().toLowerCase();
    if (!keyword) return keluargaList;
    return keluargaList.filter(
      (item) =>
        item.namaKepala.toLowerCase().includes(keyword) ||
        item.kodeKK.toLowerCase().includes(keyword),
    );
  }, [keluargaList, search]);

  const openAddModal = () => {
    setEditingId(null);
    setFormErrors({});
    setFormData({
      kode: "",
      nama_kepala_keluarga: "",
      alamat_keluarga: "",
      telp_keluarga: "",
      jumlah_anggota: "",
    });
    setIsModalOpen(true);
  };

  const openEditModal = (item: KeluargaItem) => {
    setEditingId(item.id);
    setFormErrors({});
    setFormData({
      kode: item.kodeKK === "-" ? "" : item.kodeKK,
      nama_kepala_keluarga: item.namaKepala === "-" ? "" : item.namaKepala,
      alamat_keluarga: item.alamat === "-" ? "" : item.alamat,
      telp_keluarga: item.telepon === "-" ? "" : item.telepon,
      jumlah_anggota: String(item.jumlahAnggota || ""),
    });
    setIsModalOpen(true);
  };

  const validateForm = () => {
    const errors: Partial<Record<keyof KeluargaForm, string>> = {};
    if (!formData.kode.trim()) errors.kode = "Kode KK wajib diisi";
    if (!formData.nama_kepala_keluarga.trim()) errors.nama_kepala_keluarga = "Nama kepala keluarga wajib diisi";
    if (!formData.alamat_keluarga.trim()) errors.alamat_keluarga = "Alamat wajib diisi";
    if (!formData.jumlah_anggota.trim()) errors.jumlah_anggota = "Jumlah anggota wajib diisi";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    if (!user?.id || !user?.id_puskesmas) return;

    setIsSubmitting(true);
    try {
      const payload = {
        kode: formData.kode.trim(),
        nama_kepala_keluarga: formData.nama_kepala_keluarga.trim(),
        alamat_keluarga: formData.alamat_keluarga.trim(),
        telp_keluarga: formData.telp_keluarga.trim() || null,
        jumlah_anggota: Number(formData.jumlah_anggota),
        id_puskesmas: user.id_puskesmas,
        created_by: user.id,
      };

      if (editingId) {
        await (supabase as any).from("keluarga").update(payload).eq("id", editingId);
      } else {
        await (supabase as any).from("keluarga").insert(payload);
      }

      setIsModalOpen(false);
      await fetchKeluarga();
      toast.success("Data berhasil disimpan");
    } finally {
      setIsSubmitting(false);
    }
  };

  const fetchAnggotaByKeluarga = async (keluargaId: string) => {
    setIsDetailLoading(true);
    try {
      const { data } = await (supabase as any)
        .from("anggota_keluarga")
        .select("*")
        .eq("id_keluarga", keluargaId)
        .order("urutan", { ascending: true });

      const mapped: AnggotaItem[] = ((data ?? []) as Array<Record<string, unknown>>).map((row, index) => ({
        id: String(row.id ?? index),
        nama: String(row.nama ?? row.nama_anggota ?? "-"),
        hubungan: String(row.hubungan ?? "-"),
        urutan: Number(row.urutan ?? index + 1),
      }));
      setAnggotaList(mapped);
    } finally {
      setIsDetailLoading(false);
    }
  };

  const openDetailModal = async (item: KeluargaItem) => {
    setDetailKeluarga(item);
    setAnggotaList([]);
    await fetchAnggotaByKeluarga(item.id);
  };

  const closeDetailModal = () => {
    setDetailKeluarga(null);
    setAnggotaList([]);
    setIsAnggotaModalOpen(false);
    setAnggotaForm({ nama: "", hubungan: "", urutan: "" });
    setAnggotaError({});
  };

  const openAddAnggotaModal = () => {
    setAnggotaError({});
    setAnggotaForm({ nama: "", hubungan: "", urutan: "" });
    setIsAnggotaModalOpen(true);
  };

  const validateAnggotaForm = () => {
    const errors: Partial<Record<keyof AnggotaForm, string>> = {};
    if (!anggotaForm.nama.trim()) errors.nama = "Nama wajib diisi";
    if (!anggotaForm.hubungan.trim()) errors.hubungan = "Hubungan wajib dipilih";
    if (!anggotaForm.urutan.trim()) errors.urutan = "Urutan wajib diisi";
    setAnggotaError(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveAnggota = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!detailKeluarga) return;
    if (!validateAnggotaForm()) return;

    setIsSavingAnggota(true);
    try {
      await (supabase as any).from("anggota_keluarga").insert({
        id_keluarga: detailKeluarga.id,
        nama: anggotaForm.nama.trim(),
        hubungan: anggotaForm.hubungan,
        urutan: Number(anggotaForm.urutan),
      });
      setIsAnggotaModalOpen(false);
      await fetchAnggotaByKeluarga(detailKeluarga.id);
      toast.success("Anggota keluarga berhasil disimpan");
    } finally {
      setIsSavingAnggota(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold text-foreground">Data Keluarga</h1>
        {canManage && (
          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition-opacity"
          >
            + Tambah Keluarga Baru
          </button>
        )}
      </div>

      <p className="text-muted-foreground text-sm">Kelola data keluarga (KK) di Puskesmas Anda</p>

      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Cari nama kepala keluarga atau kode KK..."
        className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
      />

      {isLoading ? (
        <div className="flex items-center justify-center gap-3 py-12 text-muted-foreground">
          <span className="h-5 w-5 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          Memuat data keluarga...
        </div>
      ) : filteredData.length === 0 ? (
        <div className="text-center py-12 bg-card border border-border rounded-lg text-muted-foreground">
          Belum ada data keluarga
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="bg-muted/40">
              <tr className="text-left">
                <th className="px-4 py-3 font-semibold text-foreground">No</th>
                <th className="px-4 py-3 font-semibold text-foreground">Kode KK</th>
                <th className="px-4 py-3 font-semibold text-foreground">Nama Kepala</th>
                <th className="px-4 py-3 font-semibold text-foreground">Alamat</th>
                <th className="px-4 py-3 font-semibold text-foreground">Telepon</th>
                <th className="px-4 py-3 font-semibold text-foreground">Jumlah Anggota</th>
                <th className="px-4 py-3 font-semibold text-foreground">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((item, index) => (
                <tr key={item.id} className="border-t border-border">
                  <td className="px-4 py-3 text-foreground">{index + 1}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex rounded-full bg-sky-100 text-sky-700 border border-sky-200 px-2 py-0.5 text-xs font-medium">
                      {item.kodeKK}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-foreground font-medium">{item.namaKepala}</td>
                  <td className="px-4 py-3 text-foreground">{item.alamat}</td>
                  <td className="px-4 py-3 text-foreground">{item.telepon}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex rounded-full bg-green-100 text-green-700 border border-green-200 px-2 py-0.5 text-xs font-medium">
                      {item.jumlahAnggota}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => openDetailModal(item)}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-blue-200 text-blue-600 hover:bg-blue-50"
                        title="Detail"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      {canManage && (
                        <>
                          <button
                            type="button"
                            onClick={() => openEditModal(item)}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-yellow-200 text-yellow-600 hover:bg-yellow-50"
                            title="Edit"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-red-200 text-red-600 hover:bg-red-50"
                            title="Hapus"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-lg border border-border bg-card">
            <div className="border-b border-border px-5 py-4">
              <h2 className="text-lg font-semibold text-foreground">{editingId ? "Edit Keluarga" : "Tambah Keluarga"}</h2>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Kode KK*</label>
                <input
                  type="text"
                  placeholder="JNG-001"
                  value={formData.kode}
                  onChange={(e) => setFormData((prev) => ({ ...prev, kode: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
                {formErrors.kode && <p className="text-xs text-red-600 mt-1">{formErrors.kode}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Nama Kepala Keluarga*</label>
                <input
                  type="text"
                  value={formData.nama_kepala_keluarga}
                  onChange={(e) => setFormData((prev) => ({ ...prev, nama_kepala_keluarga: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
                {formErrors.nama_kepala_keluarga && <p className="text-xs text-red-600 mt-1">{formErrors.nama_kepala_keluarga}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Alamat*</label>
                <textarea
                  value={formData.alamat_keluarga}
                  onChange={(e) => setFormData((prev) => ({ ...prev, alamat_keluarga: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm min-h-24"
                />
                {formErrors.alamat_keluarga && <p className="text-xs text-red-600 mt-1">{formErrors.alamat_keluarga}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Nomor Telepon</label>
                <input
                  type="text"
                  value={formData.telp_keluarga}
                  onChange={(e) => setFormData((prev) => ({ ...prev, telp_keluarga: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Jumlah Anggota*</label>
                <input
                  type="number"
                  min={1}
                  value={formData.jumlah_anggota}
                  onChange={(e) => setFormData((prev) => ({ ...prev, jumlah_anggota: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
                {formErrors.jumlah_anggota && <p className="text-xs text-red-600 mt-1">{formErrors.jumlah_anggota}</p>}
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-md border border-border px-4 py-2 text-sm text-foreground hover:bg-muted"
                  disabled={isSubmitting}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-70"
                  disabled={isSubmitting}
                >
                  {isSubmitting && (
                    <span className="mr-2 h-4 w-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                  )}
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {detailKeluarga && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-lg border border-border bg-card max-h-[90vh] overflow-y-auto">
            <div className="border-b border-border px-5 py-4">
              <h2 className="text-lg font-semibold text-foreground">Detail Keluarga</h2>
            </div>

            <div className="p-5 space-y-5">
              <div className="rounded-lg bg-muted/50 border border-border p-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Kode KK</p>
                  <p className="font-medium text-foreground">{detailKeluarga.kodeKK}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Nama Kepala</p>
                  <p className="font-medium text-foreground">{detailKeluarga.namaKepala}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Alamat</p>
                  <p className="font-medium text-foreground">{detailKeluarga.alamat}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Telepon</p>
                  <p className="font-medium text-foreground">{detailKeluarga.telepon}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Jumlah Anggota</p>
                  <p className="font-medium text-foreground">{detailKeluarga.jumlahAnggota}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground">Anggota Keluarga</h3>
                  {canManage && (
                    <button
                      type="button"
                      onClick={openAddAnggotaModal}
                      className="inline-flex items-center justify-center rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-90"
                    >
                      + Tambah Anggota
                    </button>
                  )}
                </div>

                {isDetailLoading ? (
                  <div className="text-sm text-muted-foreground">Memuat anggota keluarga...</div>
                ) : anggotaList.length === 0 ? (
                  <div className="text-sm text-muted-foreground">Belum ada data anggota keluarga.</div>
                ) : (
                  <div className="space-y-2">
                    {anggotaList.map((anggota, index) => (
                      <div key={anggota.id} className="rounded-md border border-border p-3 flex items-center justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-foreground">{anggota.nama}</p>
                          <p className="text-xs text-muted-foreground">{anggota.hubungan}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs rounded-full bg-muted px-2 py-1 text-foreground">#{anggota.urutan || index + 1}</span>
                          {canManage && (
                            <>
                              <button
                                type="button"
                                onClick={() => toast.info("Edit anggota belum tersedia")}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-yellow-200 text-yellow-600 hover:bg-yellow-50"
                                title="Edit anggota"
                              >
                                <Pencil className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => toast.info("Hapus anggota belum tersedia")}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-red-200 text-red-600 hover:bg-red-50"
                                title="Hapus anggota"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={closeDetailModal}
                  className="rounded-md border border-border px-4 py-2 text-sm text-foreground hover:bg-muted"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isAnggotaModalOpen && detailKeluarga && (
        <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-lg border border-border bg-card">
            <div className="border-b border-border px-5 py-4">
              <h3 className="text-base font-semibold text-foreground">Tambah Anggota</h3>
            </div>
            <form onSubmit={handleSaveAnggota} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Nama*</label>
                <input
                  type="text"
                  value={anggotaForm.nama}
                  onChange={(e) => setAnggotaForm((prev) => ({ ...prev, nama: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
                {anggotaError.nama && <p className="text-xs text-red-600 mt-1">{anggotaError.nama}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Hubungan*</label>
                <select
                  value={anggotaForm.hubungan}
                  onChange={(e) => setAnggotaForm((prev) => ({ ...prev, hubungan: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                >
                  <option value="">Pilih hubungan</option>
                  <option value="Ayah">Ayah</option>
                  <option value="Ibu">Ibu</option>
                  <option value="Anak">Anak</option>
                  <option value="Kakek">Kakek</option>
                  <option value="Nenek">Nenek</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
                {anggotaError.hubungan && <p className="text-xs text-red-600 mt-1">{anggotaError.hubungan}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Urutan*</label>
                <input
                  type="number"
                  min={1}
                  value={anggotaForm.urutan}
                  onChange={(e) => setAnggotaForm((prev) => ({ ...prev, urutan: e.target.value }))}
                  className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
                />
                {anggotaError.urutan && <p className="text-xs text-red-600 mt-1">{anggotaError.urutan}</p>}
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAnggotaModalOpen(false)}
                  className="rounded-md border border-border px-4 py-2 text-sm text-foreground hover:bg-muted"
                  disabled={isSavingAnggota}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-70"
                  disabled={isSavingAnggota}
                >
                  {isSavingAnggota && (
                    <span className="mr-2 h-4 w-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                  )}
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
