import { useNavigate } from "react-router-dom";
import sikakLogo from "@/assets/sikak-logo.png";
import {
  Heart,
  Shield,
  Users,
  FileText,
  Activity,
  Phone,
  ChevronRight,
  Stethoscope,
  Baby,
  Pill,
  Syringe,
  Apple,
  Brain,
  LogIn,
  UserPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const healthTips = [
  "💊 Jangan lupa minum obat sesuai jadwal yang ditentukan dokter",
  "🥗 Konsumsi sayur dan buah minimal 5 porsi sehari untuk kesehatan optimal",
  "🏃 Lakukan aktivitas fisik minimal 30 menit setiap hari",
  "💧 Minum air putih minimal 8 gelas sehari",
  "😴 Tidur yang cukup 7-8 jam sehari untuk menjaga imunitas tubuh",
  "🧼 Cuci tangan pakai sabun untuk mencegah penyebaran penyakit",
  "🩺 Lakukan pemeriksaan kesehatan rutin di Puskesmas terdekat",
  "🚭 Hindari rokok dan paparan asap rokok untuk kesehatan paru-paru",
];

const services = [
  { icon: Stethoscope, title: "Pemeriksaan Umum", desc: "Layanan pemeriksaan kesehatan umum untuk seluruh anggota keluarga" },
  { icon: Baby, title: "Kesehatan Ibu & Anak", desc: "Pemantauan tumbuh kembang anak dan kesehatan ibu hamil" },
  { icon: Syringe, title: "Imunisasi", desc: "Program imunisasi lengkap sesuai jadwal Kementerian Kesehatan" },
  { icon: Apple, title: "Gizi & Nutrisi", desc: "Konsultasi gizi dan pemantauan status nutrisi keluarga" },
  { icon: Brain, title: "Kesehatan Jiwa", desc: "Layanan konseling dan dukungan kesehatan mental" },
  { icon: Pill, title: "Program Penyakit Kronis", desc: "Pengelolaan penyakit kronis seperti hipertensi dan diabetes" },
];

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={sikakLogo} alt="Logo SIKAK" width={40} height={40} />
            <div>
              <h1 className="text-lg font-bold text-primary leading-tight">SIKAK</h1>
              <p className="text-[10px] text-muted-foreground leading-tight">Sistem Informasi Kartu Asuhan Keperawatan</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => navigate("/register")} className="gap-2 hidden sm:flex">
              <UserPlus className="h-4 w-4" />
              Daftar
            </Button>
            <Button onClick={() => navigate("/login")} className="gap-2">
              <LogIn className="h-4 w-4" />
              Masuk
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent to-secondary py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1 animate-fade-in">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground leading-tight">
              Digitalisasi <span className="text-primary">Asuhan Keperawatan</span> Keluarga
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-xl">
              Sistem informasi terpadu untuk pencatatan, pengelolaan, dan pelaporan kartu asuhan keperawatan keluarga di seluruh Puskesmas Kabupaten Ponorogo.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" onClick={() => navigate("/login")} className="gap-2">
                <LogIn className="h-5 w-5" />
                Masuk ke Sistem
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate("/register")} className="gap-2">
                <UserPlus className="h-5 w-5" />
                Daftar Akun
              </Button>
            </div>
          </div>
          <div className="flex-1 flex justify-center animate-fade-in">
            <img src={sikakLogo} alt="SIKAK Logo" width={300} height={300} className="animate-float drop-shadow-xl" />
          </div>
        </div>
      </section>

      {/* Marquee */}
      <div className="bg-primary py-3 overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...healthTips, ...healthTips].map((tip, i) => (
            <span key={i} className="mx-8 text-sm text-primary-foreground font-medium">{tip}</span>
          ))}
        </div>
      </div>

      {/* Services */}
      <section id="layanan" className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground">Layanan Kesehatan Puskesmas</h3>
            <p className="text-muted-foreground mt-2">Program pelayanan kesehatan yang tersedia untuk keluarga Indonesia</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((svc, i) => (
              <div key={svc.title} className="p-6 rounded-lg border border-border bg-card hover:shadow-lg hover:border-primary/30 transition-all duration-300 animate-fade-in" style={{ animationDelay: `${i * 80}ms` }}>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <svc.icon className="h-6 w-6 text-primary" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{svc.title}</h4>
                <p className="text-sm text-muted-foreground">{svc.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section className="py-16 bg-accent/30">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Tentang SIKAK</h3>
            <p className="text-muted-foreground mb-4">
              SIKAK (Sistem Informasi Kartu Asuhan Keperawatan) adalah platform digital yang dikembangkan untuk menggantikan pencatatan manual kartu asuhan keperawatan keluarga di Puskesmas Kabupaten Ponorogo.
            </p>
            <ul className="space-y-3">
              {[
                "Pencatatan digital terstruktur sesuai format Kemenkes",
                "Ekspor PDF siap cetak format A4 portrait",
                "Dashboard analitik untuk monitoring kinerja",
                "Manajemen data keluarga yang efisien",
                "Akses multi-petugas dengan keamanan terjamin",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-foreground">
                  <ChevronRight className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex-1 flex justify-center">
            <div className="bg-card rounded-lg border border-border p-8 shadow-lg max-w-sm w-full">
              <Heart className="h-16 w-16 text-primary mx-auto mb-4 animate-pulse-soft" />
              <h4 className="text-center font-bold text-foreground text-lg mb-2">Kesehatan Keluarga Prioritas Utama</h4>
              <p className="text-center text-sm text-muted-foreground">
                Setiap keluarga berhak mendapatkan pelayanan kesehatan yang berkualitas dan terdokumentasi dengan baik.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency */}
      <section className="py-12 bg-card">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="text-xl font-bold text-foreground mb-6">Kontak Darurat & Informasi</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg border border-border">
              <Phone className="h-6 w-6 text-primary mx-auto mb-2" />
              <p className="font-semibold text-foreground">Hotline Kesehatan</p>
              <p className="text-primary font-bold text-lg">119</p>
            </div>
            <div className="p-4 rounded-lg border border-border">
              <Shield className="h-6 w-6 text-primary mx-auto mb-2" />
              <p className="font-semibold text-foreground">BPJS Kesehatan</p>
              <p className="text-primary font-bold text-lg">165</p>
            </div>
            <div className="p-4 rounded-lg border border-border">
              <Activity className="h-6 w-6 text-primary mx-auto mb-2" />
              <p className="font-semibold text-foreground">Ambulans</p>
              <p className="text-primary font-bold text-lg">118 / 021-65303118</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary/5 border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={sikakLogo} alt="SIKAK" width={32} height={32} />
              <div>
                <p className="font-bold text-foreground text-sm">SIKAK v1.0</p>
                <p className="text-xs text-muted-foreground">Sistem Informasi Kartu Asuhan Keperawatan</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              © 2026 - Pemerintahan Kabupaten Ponorogo
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
