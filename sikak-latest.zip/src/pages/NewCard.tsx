import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

type KeluargaOption = { id: string; nama: string; kode: string };
type AnggotaOption = {
  id: string;
  idKeluarga: string;
  nama: string;
  hubungan: string;
};

export default function NewCard() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const daftarMasukId = searchParams.get("id_daftar_masuk");

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [keluargaOptions, setKeluargaOptions] = useState<KeluargaOption[]>([]);
  const [anggotaOptions, setAnggotaOptions] = useState<AnggotaOption[]>([]);
  const [selectedKeluargaId, setSelectedKeluargaId] = useState("");
  const [selectedAnggotaId, setSelectedAnggotaId] = useState("");
  const [poliName, setPoliName] = useState("-");
  const [tanggalKunjungan, setTanggalKunjungan] = useState(
    new Date().toISOString().slice(0, 10),
  );
  const [dataPengkajian, setDataPengkajian] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [rencanaIntervensi, setRencanaIntervensi] = useState("");
  const [implementasi, setImplementasi] = useState("");
  const [petugasKesehatan, setPetugasKesehatan] = useState("");

  useEffect(() => {
    const fetchInitialData = async () => {
      const idPuskesmas = user?.id_puskesmas;
      if (!idPuskesmas) {
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const [keluargaRes, anggotaRes, poliRes] = await Promise.all([
          (supabase as any)
            .from("keluarga")
            .select("id, nama_kepala_keluarga, kode")
            .eq("id_puskesmas", idPuskesmas)
            .order("nama_kepala_keluarga", { ascending: true }),
          (supabase as any)
            .from("anggota_keluarga")
            .select("id, id_keluarga, nama, hubungan"),
          user?.id_poli
            ? (supabase as any)
                .from("poli")
                .select("*")
                .eq("id", user.id_poli)
                .maybeSingle()
            : Promise.resolve({ data: null }),
        ]);

        const keluargaMapped: KeluargaOption[] = (
          (keluargaRes.data ?? []) as Array<Record<string, unknown>>
        ).map((row, idx) => ({
          id: String(row.id ?? idx),
          nama: String(row.nama_kepala_keluarga ?? "-"),
          kode: String(row.kode ?? "-"),
        }));
        const anggotaMapped: AnggotaOption[] = (
          (anggotaRes.data ?? []) as Array<Record<string, unknown>>
        ).map((row, idx) => ({
          id: String(row.id ?? idx),
          idKeluarga: String(row.id_keluarga ?? ""),
          nama: String(row.nama ?? "-"),
          hubungan: String(row.hubungan ?? "-"),
        }));
        setKeluargaOptions(keluargaMapped);
        setAnggotaOptions(anggotaMapped);
        setPoliName(
          String(
            (poliRes as any).data?.nama_poli ??
              (poliRes as any).data?.nama ??
              (poliRes as any).data?.name ??
              "-",
          ),
        );

        if (daftarMasukId) {
          const { data } = await (supabase as any)
            .from("daftar_masuk")
            .select("*")
            .eq("id", daftarMasukId)
            .maybeSingle();
          if (data) {
            setSelectedKeluargaId(String(data.id_keluarga ?? ""));
            setSelectedAnggotaId(String(data.id_anggota_keluarga ?? ""));
          }
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchInitialData();
  }, [daftarMasukId, user?.id_poli, user?.id_puskesmas]);

  const anggotaCascade = useMemo(
    () =>
      anggotaOptions.filter((item) => item.idKeluarga === selectedKeluargaId),
    [anggotaOptions, selectedKeluargaId],
  );
  const keluargaAktif = keluargaOptions.find(
    (item) => item.id === selectedKeluargaId,
  );
  const anggotaAktif = anggotaOptions.find(
    (item) => item.id === selectedAnggotaId,
  );

  const saveCard = async () => {
    if (
      !user?.id ||
      !user?.id_puskesmas ||
      !selectedKeluargaId ||
      !selectedAnggotaId
    ) {
      throw new Error("Data pasien belum lengkap");
    }
    const { data: card } = await (supabase as any)
      .from("kartu_asuhan_keperawatan")
      .insert({
        id_keluarga: selectedKeluargaId,
        id_anggota_keluarga: selectedAnggotaId,
        id_daftar_masuk: daftarMasukId || null,
        id_poli: user.id_poli,
        status: "pending",
        created_by: user.id,
      })
      .select("id")
      .single();

    await (supabase as any).from("kak_rows").insert({
      id_kak: card.id,
      tanggal: tanggalKunjungan,
      data_pengkajian: dataPengkajian,
      diagnosis_keperawatan: diagnosis,
      rencana_intervensi: rencanaIntervensi,
      implementasi,
      petugas: petugasKesehatan,
    });
  };

  const handleSave = async (shouldPrint: boolean) => {
    setIsSaving(true);
    try {
      await saveCard();
      toast.success("Kartu asuhan berhasil disimpan");
      if (shouldPrint) {
        window.print();
      }
      navigate("/app/kartu");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold text-foreground">
        Input Kartu Asuhan Keperawatan
      </h1>

      {isLoading ? (
        <div className="flex items-center gap-3 py-10 text-muted-foreground">
          <span className="h-5 w-5 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          Memuat data pasien...
        </div>
      ) : (
        <>
          {!daftarMasukId && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <select
                value={selectedKeluargaId}
                onChange={(e) => {
                  setSelectedKeluargaId(e.target.value);
                  setSelectedAnggotaId("");
                }}
                className="rounded-md border border-border bg-background px-3 py-2 text-sm"
              >
                <option value="">Pilih Keluarga</option>
                {keluargaOptions.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.nama} ({item.kode})
                  </option>
                ))}
              </select>
              <select
                value={selectedAnggotaId}
                onChange={(e) => setSelectedAnggotaId(e.target.value)}
                className="rounded-md border border-border bg-background px-3 py-2 text-sm"
              >
                <option value="">Pilih Anggota</option>
                {anggotaCascade.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.nama} ({item.hubungan})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-2 text-sm">
            <p className="text-foreground">
              Keluarga:{" "}
              <span className="font-medium">{keluargaAktif?.nama ?? "-"}</span>{" "}
              ({keluargaAktif?.kode ?? "-"})
            </p>
            <p className="text-foreground">
              Anggota:{" "}
              <span className="font-medium">{anggotaAktif?.nama ?? "-"}</span> (
              {anggotaAktif?.hubungan ?? "-"})
            </p>
            <p className="text-foreground">
              Poli: <span className="font-medium">{poliName}</span>
            </p>
            <div className="flex items-center gap-2">
              <span className="text-foreground">Tanggal Kunjungan:</span>
              <input
                type="date"
                value={tanggalKunjungan}
                onChange={(e) => setTanggalKunjungan(e.target.value)}
                className="rounded-md border border-border bg-background px-3 py-1.5 text-sm"
              />
            </div>
          </div>

          <div className="space-y-4">
            <FormSection
              title="1. Data Pengkajian"
              placeholder="Masukkan hasil pengkajian kesehatan..."
              value={dataPengkajian}
              onChange={setDataPengkajian}
            />
            <FormSection
              title="2. Diagnosis Keperawatan"
              placeholder="Masukkan diagnosis keperawatan..."
              value={diagnosis}
              onChange={setDiagnosis}
            />
            <FormSection
              title="3. Rencana Intervensi"
              placeholder="Masukkan rencana tindakan keperawatan..."
              value={rencanaIntervensi}
              onChange={setRencanaIntervensi}
            />
            <FormSection
              title="4. Implementasi"
              placeholder="Masukkan hasil implementasi/tindakan..."
              value={implementasi}
              onChange={setImplementasi}
            />
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                5. Petugas Kesehatan
              </label>
              <input
                type="text"
                value={petugasKesehatan}
                onChange={(e) => setPetugasKesehatan(e.target.value)}
                placeholder="Nama petugas yang mendokumentasikan"
                className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => navigate("/app/kartu")}
              className="rounded-md border border-border px-4 py-2 text-sm text-foreground hover:bg-muted"
              disabled={isSaving}
            >
              Batal
            </button>
            <button
              type="button"
              onClick={() => handleSave(false)}
              className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-70"
              disabled={isSaving}
            >
              {isSaving && (
                <span className="mr-2 h-4 w-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
              )}
              Simpan
            </button>
            <button
              type="button"
              onClick={() => handleSave(true)}
              className="inline-flex items-center rounded-md border border-primary px-4 py-2 text-sm font-medium text-primary hover:bg-primary/5 disabled:opacity-70"
              disabled={isSaving}
            >
              Simpan & Cetak
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function FormSection({
  title,
  placeholder,
  value,
  onChange,
}: {
  title: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-foreground mb-1">
        {title}
      </label>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full min-h-24 rounded-md border border-border bg-background px-3 py-2 text-sm resize-y"
      />
    </div>
  );
}
