import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { CardFormData } from "@/types/careCard";
import { CardHeader } from "@/components/CardHeader";
import { ReportTable } from "@/components/ReportTable";
import { useCareCard, useCareReportRows, useCareCards } from "@/hooks/useCareCards";
import { exportToPDF } from "@/utils/pdfExport";
import { Button } from "@/components/ui/button";
import { Save, RotateCcw, ArrowLeft, FileDown, Loader2 } from "lucide-react";

export default function CardDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: card, isLoading: cardLoading } = useCareCard(id);
  const { updateCard, isUpdating } = useCareCards();
  const {
    rows, isLoading: rowsLoading, createRow, updateRow, deleteRow, isCreating, isUpdating: isRowUpdating,
  } = useCareReportRows(id);

  const [formData, setFormData] = useState<CardFormData>({
    puskesmas: "", kepala_keluarga: "", alamat: "", kode: "", telp: "", masalah_kesehatan: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (card) {
      setFormData({
        puskesmas: card.puskesmas, kepala_keluarga: card.kepala_keluarga, alamat: card.alamat,
        kode: card.kode || "", telp: card.telp || "", masalah_kesehatan: card.masalah_kesehatan || "",
      });
    }
  }, [card]);

  const handleChange = (field: keyof CardFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    if (!id) return;
    await updateCard({ id, ...formData });
    setIsEditing(false);
  };

  const handleReset = () => {
    if (card) {
      setFormData({
        puskesmas: card.puskesmas, kepala_keluarga: card.kepala_keluarga, alamat: card.alamat,
        kode: card.kode || "", telp: card.telp || "", masalah_kesehatan: card.masalah_kesehatan || "",
      });
    }
    setIsEditing(false);
  };

  const handleExportPDF = () => {
    if (card) exportToPDF(card, rows);
  };

  if (cardLoading || rowsLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!card) {
    return (
      <div className="flex items-center justify-center py-20 flex-col gap-4">
        <p className="text-muted-foreground">Kartu tidak ditemukan</p>
        <Button onClick={() => navigate("/app/kartu")}>Kembali</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="no-print">
        <Button variant="ghost" onClick={() => navigate("/app/kartu")} className="gap-2 -ml-2">
          <ArrowLeft className="h-4 w-4" />
          Kembali
        </Button>
      </div>

      <CardHeader formData={formData} onChange={handleChange} isEditing={isEditing} />

      <div className="flex flex-wrap gap-3 no-print">
        {isEditing ? (
          <>
            <Button onClick={handleSave} disabled={isUpdating} className="gap-2">
              <Save className="h-4 w-4" />
              {isUpdating ? "Menyimpan..." : "Simpan Perubahan"}
            </Button>
            <Button variant="outline" onClick={handleReset} className="gap-2">
              <RotateCcw className="h-4 w-4" />
              Batal
            </Button>
          </>
        ) : (
          <Button variant="outline" onClick={() => setIsEditing(true)} className="gap-2">
            Edit Info Kartu
          </Button>
        )}
        <Button variant="outline" onClick={handleExportPDF} className="gap-2">
          <FileDown className="h-4 w-4" />
          Cetak PDF
        </Button>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-4 text-foreground">Laporan Asuhan Keperawatan</h2>
        <ReportTable
          rows={rows} cardId={id!} onAddRow={createRow} onUpdateRow={updateRow}
          onDeleteRow={deleteRow} isCreating={isCreating} isUpdating={isRowUpdating}
        />
      </div>
    </div>
  );
}
