export default function CetakPage() {
  return <div>Cetak - Coming Soon</div>;
}
